package ru.job4j.generics;

import java.util.Date;

public class Predator extends Animal {
    public Predator(String name, String type, int age) {
        super(name, type);
    }

}
