package ru.job4j;

public class Trigger {
    public int someLogic() {
        return 1;
    }
}