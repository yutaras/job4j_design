# job4j_design
[![Build Status](https://app.travis-ci.com/yutaras/job4j_design.svg?branch=master)](https://app.travis-ci.com/yutaras/job4j_design)
[![codecov](https://codecov.io/gh/yutaras/job4j_design/branch/master/graph/badge.svg?token=MTY4P4WABR)](https://codecov.io/gh/yutaras/job4j_design)
