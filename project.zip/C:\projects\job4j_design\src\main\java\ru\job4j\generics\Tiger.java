package ru.job4j.generics;

public class Tiger extends Predator {
    public Tiger(String name, String type, int age, int speed) {
        super(name, type, age);
    }
}
